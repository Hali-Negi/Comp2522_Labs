package ca.bcit.comp2522.bookstore;

public interface Printable
{
    void display();
}
